from example.blog.models import EncObject
from django.contrib import admin

admin.site.register(EncObject)
